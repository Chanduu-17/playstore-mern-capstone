import React, { Component } from "react";

class AuthorInfo extends Component {

  componentDidMount() {
    console.log("AuthorInfo component mounted");
  }

  render() {
    const { author } = this.props;

    if (!author) return null;

    return (
      <div className="card mt-4 p-4 bg-light shadow">
        <h4 className="text-dark">Author Details</h4>
        <p><strong>Bio:</strong> {author.bio}</p>

        <h6 className="mt-3">Top 3 Books:</h6>
        <ul>
          {author.topBooks.map((book, index) => (
            <li key={index}>{book}</li>
          ))}
        </ul>
      </div>
    );
  }
}

export default AuthorInfo;