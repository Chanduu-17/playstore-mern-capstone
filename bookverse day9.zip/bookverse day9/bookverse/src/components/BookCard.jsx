import React from "react";
import PropTypes from "prop-types";

const BookCard = ({ book, onSelect }) => {
  return (
    <div 
      className="card shadow-lg h-100 book-card"
      onClick={() => onSelect(book)}
    >
      <div className="card-body text-center">
        <h5 className="card-title text-primary">{book.title}</h5>
        <p className="card-text">Author: {book.author}</p>
        <p className="card-text text-success fw-bold">₹{book.price}</p>
      </div>
    </div>
  );
};

BookCard.propTypes = {
  book: PropTypes.shape({
    title: PropTypes.string.isRequired,
    author: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
  }).isRequired,
  onSelect: PropTypes.func.isRequired,
};

export default BookCard;