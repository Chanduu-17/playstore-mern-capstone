import React, { Component, createRef } from "react";
import BookCard from "./BookCard";
import AuthorInfo from "./AuthorInfo";

class BookList extends Component {

  constructor(props) {
    super(props);

    this.searchRef = createRef();

    this.state = {
      books: [
        {
          id: 1,
          title: "Atomic Habits",
          author: "James Clear",
          price: 499,
          bio: "James Clear focuses on habits and productivity.",
          topBooks: ["Atomic Habits", "Habit Mastery", "Clear Thinking"],
        },
        {
          id: 2,
          title: "The Alchemist",
          author: "Paulo Coelho",
          price: 299,
          bio: "Paulo Coelho is a Brazilian novelist.",
          topBooks: ["The Alchemist", "Brida", "Eleven Minutes"],
        },
      ],
      selectedAuthor: null,
    };
  }

  componentDidMount() {
    console.log("BookList mounted - Books loaded");
  }

  focusSearch = () => {
    this.searchRef.current.focus();
  };

  handleSelect = (book) => {
    this.setState({
      selectedAuthor: {
        bio: book.bio,
        topBooks: book.topBooks,
      },
    });
  };

  render() {
    return (
      <div className="container mt-4">

        <div className="d-flex mb-3">
          <input
            type="text"
            className="form-control me-2"
            placeholder="Search books..."
            ref={this.searchRef}
          />
          <button
            className="btn btn-primary"
            onClick={this.focusSearch}
          >
            Focus Search
          </button>
        </div>

        <div className="row">
          {this.state.books.map((book) => (
            <div key={book.id} className="col-md-4 mb-3">
              <BookCard book={book} onSelect={this.handleSelect} />
            </div>
          ))}
        </div>

        <AuthorInfo author={this.state.selectedAuthor} />

      </div>
    );
  }
}

export default BookList;