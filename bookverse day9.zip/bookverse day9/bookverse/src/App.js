import React from "react";
import BookList from "./components/BookList";
import "./App.css";

function App() {
  return (
    <div className="bg-light min-vh-100">
      <h1 className="text-center text-primary py-4">
        📚 BookVerse - Author Explorer
      </h1>
      <BookList />
    </div>
  );
}

export default App;