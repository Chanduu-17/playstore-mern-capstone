const fs = require("fs").promises;

// delay function
function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function copyFile() {

    try {

        const data = await fs.readFile("input.txt", "utf8");

        // simulate slow operation
        await wait(1000);

        await fs.writeFile("output.txt", data);

        console.log("File copied successfully using async/await!");

    } catch (error) {

        console.error("Operation failed:", error);

    }

}

copyFile();