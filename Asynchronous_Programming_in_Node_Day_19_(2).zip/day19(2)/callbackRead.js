const fs = require("fs");

// Read file asynchronously using callback
fs.readFile("data.txt", "utf8", (err, data) => {

    if (err) {
        console.error("Error reading file:", err);
        return;
    }

    console.log("File Content:");
    console.log(data);

    // bonus delay before confirmation
    setTimeout(() => {
        console.log("Read operation completed");
    }, 1500);

});