import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { addBook } from "../flux/actions";
import "../App.css";

function AddBook() {
  const navigate = useNavigate();
  const [success, setSuccess] = useState(false);

  const validationSchema = Yup.object({
    title: Yup.string().required("Title is required"),
    author: Yup.string().required("Author is required"),
    price: Yup.number()
      .typeError("Price must be a number")
      .required("Price is required")
  });

  return (
    <div className="container">
      <h2>Add New Book</h2>

      {success && <div className="toast">Book Added Successfully!</div>}

      <Formik
        initialValues={{ title: "", author: "", price: "" }}
        validationSchema={validationSchema}
        onSubmit={(values, { resetForm }) => {
          addBook(values);
          setSuccess(true);
          resetForm();

          setTimeout(() => {
            setSuccess(false);
            navigate("/");
          }, 1000);
        }}
      >
        <Form>
          <Field name="title" placeholder="Title" />
          <ErrorMessage name="title" component="div" className="error" />

          <Field name="author" placeholder="Author" />
          <ErrorMessage name="author" component="div" className="error" />

          <Field name="price" type="number" placeholder="Price" />
          <ErrorMessage name="price" component="div" className="error" />

          <button type="submit" className="button-primary">
            Add Book
          </button>
        </Form>
      </Formik>
    </div>
  );
}

export default AddBook;