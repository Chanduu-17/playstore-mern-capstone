import { useEffect, useState } from "react";
import Store from "../flux/store";
import { deleteBook } from "../flux/actions";
import "../App.css";

function Home() {
  const [books, setBooks] = useState(Store.getBooks());

  useEffect(() => {
    Store.addChangeListener(() => {
      setBooks([...Store.getBooks()]);
    });
  }, []);

  return (
    <div className="container">
      <h2>📚 Book List</h2>

      {books.map((book) => (
        <div key={book.id} className="book-card">
          <div>
            <h3>{book.title}</h3>
            <p>{book.author}</p>
            <p><strong>₹{book.price}</strong></p>
          </div>

          <button
            className="button-danger"
            onClick={() => deleteBook(book.id)}
          >
            Delete
          </button>
        </div>
      ))}
    </div>
  );
}

export default Home;