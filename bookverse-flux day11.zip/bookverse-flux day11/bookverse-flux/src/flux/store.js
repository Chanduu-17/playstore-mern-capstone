import Dispatcher from "./dispatcher";

let books = [
  { id: 1, title: "Atomic Habits", author: "James Clear", price: 499 }
];

let listeners = [];

const Store = {
  getBooks() {
    return books;
  },

  addChangeListener(listener) {
    listeners.push(listener);
  },

  emitChange() {
    listeners.forEach((listener) => listener());
  }
};

Dispatcher.register((action) => {
  switch (action.type) {
    case "ADD_BOOK":
      books.push({
        id: books.length + 1,
        ...action.payload
      });
      Store.emitChange();
      break;

    case "DELETE_BOOK":
      books = books.filter(book => book.id !== action.payload);
      Store.emitChange();
      break;

    default:
      break;
  }
});

export default Store;