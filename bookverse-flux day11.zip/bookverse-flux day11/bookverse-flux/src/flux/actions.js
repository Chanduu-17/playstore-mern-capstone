import Dispatcher from "./dispatcher";

export const addBook = (book) => {
  Dispatcher.dispatch({
    type: "ADD_BOOK",
    payload: book
  });
};

export const deleteBook = (id) => {
  Dispatcher.dispatch({
    type: "DELETE_BOOK",
    payload: id
  });
};