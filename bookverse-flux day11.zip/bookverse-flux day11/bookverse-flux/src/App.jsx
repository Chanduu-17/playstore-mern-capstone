import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import AddBook from "./pages/AddBook";
import "./App.css";

function App() {
  return (
    <BrowserRouter>
      <div className="navbar">
        <h1>📚 BookVerse</h1>
        <div className="nav-links">
          <Link to="/">Home</Link>
          <Link to="/add">Add Book</Link>
        </div>
      </div>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/add" element={<AddBook />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;