const mongoose = require("mongoose");

mongoose.connect("mongodb://127.0.0.1:27017/skillsphere")
.then(()=>console.log("MongoDB Connected"))
.catch(err=>console.log(err));

const userSchema = new mongoose.Schema({
name:String,
email:String
});

const enrollmentSchema = new mongoose.Schema({
course:String,
userId:String
});

const User = mongoose.model("User",userSchema);
const Enrollment = mongoose.model("Enrollment",enrollmentSchema);

async function fetchEnrollments(){

await User.create({name:"Rahul",email:"rahul@gmail.com"});

await Enrollment.create({
course:"Node.js",
userId:"Rahul"
});

const enrollments = await Enrollment.find();

console.log("Enrollment Details:");
console.log(enrollments);

mongoose.connection.close();
}

fetchEnrollments();