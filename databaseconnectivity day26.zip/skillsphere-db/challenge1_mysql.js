require('dotenv').config();
const mysql = require('mysql2');

const connection = mysql.createConnection({
host: process.env.MYSQL_HOST,
user: process.env.MYSQL_USER,
password: process.env.MYSQL_PASSWORD,
database: process.env.MYSQL_DATABASE
});

connection.connect(err => {
if (err) {
console.error("Connection failed:", err);
return;
}

console.log("MySQL Connected");

const sql = "INSERT INTO courses (title, description) VALUES (?, ?)";

connection.query(sql, ["Node.js Basics", "Learn backend with Node"], (err,result)=>{
if(err) throw err;

console.log("Course inserted successfully");
connection.end();
});
});