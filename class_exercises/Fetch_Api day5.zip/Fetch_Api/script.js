// MODULE PATTERN
const App = (function () {

    const output = document.getElementById("output");
    const message = document.getElementById("message");

    function clearScreen() {
        output.innerHTML = "";
        message.innerText = "";
    }

    function showLoading(text) {
        message.innerText = text;
    }

    // Convert API title into clean English sentence
    function formatTitle(title) {
        return "Blog Title: " + title.charAt(0).toUpperCase() + title.slice(1) + ".";
    }

    // Convert API body into clean English paragraph
    function formatBody(body) {
        return "Description: " + body.charAt(0).toUpperCase() + body.slice(1) + ".";
    }

    function displayPosts(posts) {
        posts.slice(0, 10).forEach(post => {
            const card = document.createElement("div");
            card.className = "card";

            card.innerHTML = `
                <h3>${formatTitle(post.title)}</h3>
                <p>${formatBody(post.body)}</p>
                <p>This article presents valuable insights for readers in a clear and structured manner.</p>
            `;

            output.appendChild(card);
        });
    }

    function displayTodos(todos) {
        todos.slice(0, 10).forEach(todo => {
            const card = document.createElement("div");
            card.className = "card";

            card.innerHTML = `
                <h3>Task Description: ${todo.title.charAt(0).toUpperCase() + todo.title.slice(1)}</h3>
                <p class="status ${todo.completed ? 'completed' : 'pending'}">
                    ${todo.completed
                        ? "This task has been successfully completed."
                        : "This task is currently pending and requires attention."}
                </p>
            `;

            output.appendChild(card);
        });
    }

    async function fetchPosts() {
        clearScreen();
        showLoading("Loading blog posts. Please wait...");

        try {
            const response = await fetch("https://jsonplaceholder.typicode.com/posts");

            if (!response.ok) {
                throw new Error("Unable to retrieve blog posts.");
            }

            const data = await response.json();
            message.innerText = "Blog posts loaded successfully.";
            displayPosts(data);

        } catch (error) {
            message.innerText = "Error: Unable to load blog posts. Please try again later.";
        }
    }

    async function fetchTodos() {
        clearScreen();
        showLoading("Loading todo list. Please wait...");

        try {
            const response = await fetch("https://jsonplaceholder.typicode.com/todos");

            if (!response.ok) {
                throw new Error("Unable to retrieve todo list.");
            }

            const data = await response.json();
            message.innerText = "Todo list loaded successfully.";
            displayTodos(data);

        } catch (error) {
            message.innerText = "Error: Unable to load todo list. Please try again later.";
        }
    }

    return {
        loadPosts: fetchPosts,
        loadTodos: fetchTodos
    };

})();

document.getElementById("loadPosts").addEventListener("click", App.loadPosts);
document.getElementById("loadTodos").addEventListener("click", App.loadTodos);