const express = require("express");
const { body, validationResult } = require("express-validator");
const rateLimit = require("express-rate-limit");

const app = express();
const PORT = 4000;

app.use(express.json());


let requestLog = {};

function rateLimiter(req, res, next) {

    const ip = req.ip;
    const now = Date.now();

    if (!requestLog[ip]) {
        requestLog[ip] = [];
    }

    requestLog[ip] = requestLog[ip].filter(
        time => now - time < 60000
    );

    if (requestLog[ip].length >= 5) {
        return res.status(429).json({
            error: "Too many requests"
        });
    }

    requestLog[ip].push(now);

    next();
}

/* Apply limiter to API routes */

app.use("/api/v1/courses", rateLimiter);



const limiter = rateLimit({
    windowMs: 60 * 1000,
    max: 5,
    message: { error: "Too many requests" }
});

app.use("/api/courses", limiter);




let courses = [
    { id: 1, name: "Node.js Basics", duration: "4 weeks" },
    { id: 2, name: "React Fundamentals", duration: "6 weeks" }
];




// GET all courses
app.get("/api/v1/courses", (req, res) => {

    res.json(courses);

});


// GET single course
app.get("/api/v1/courses/:id", (req, res) => {

    const id = parseInt(req.params.id);

    const course = courses.find(c => c.id === id);

    if (!course) {
        return res.status(404).json({ error: "Course not found" });
    }

    res.json(course);

});




app.post(
    "/api/v1/courses",
    body("name").notEmpty().withMessage("Course name is required"),
    body("duration").notEmpty().withMessage("Course duration is required"),

    (req, res) => {

        const errors = validationResult(req);

        if (!errors.isEmpty()) {
            return res.status(400).json({ error: errors.array()[0].msg });
        }

        const newCourse = {
            id: courses.length + 1,
            name: req.body.name,
            duration: req.body.duration
        };

        courses.push(newCourse);

        res.json({
            message: "Course created",
            course: newCourse
        });

    }
);


// UPDATE course
app.put("/api/v1/courses/:id", (req, res) => {

    const id = parseInt(req.params.id);

    const course = courses.find(c => c.id === id);

    if (!course) {
        return res.status(404).json({ error: "Course not found" });
    }

    course.name = req.body.name || course.name;
    course.duration = req.body.duration || course.duration;

    res.json({
        message: "Course updated",
        course
    });

});


// DELETE course
app.delete("/api/v1/courses/:id", (req, res) => {

    const id = parseInt(req.params.id);

    const courseIndex = courses.findIndex(c => c.id === id);

    if (courseIndex === -1) {
        return res.status(404).json({ error: "Course not found" });
    }

    courses.splice(courseIndex, 1);

    res.json({
        message: "Course deleted"
    });

});




app.listen(PORT, () => {

    console.log(`Server running at http://localhost:${PORT}`);

});