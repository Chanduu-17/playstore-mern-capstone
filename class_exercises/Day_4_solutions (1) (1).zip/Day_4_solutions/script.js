// Store registered students in array (As per requirement)
let students = [];

// Monthly Activities Array
let monthlyActivities = [
    { id: 1, activity: "Create tables from 12 to 19", subject: "Maths" },
    { id: 2, activity: "Practice Algebra Problems", subject: "Maths" },
    { id: 3, activity: "Draw Human Digestive System", subject: "Science" },
    { id: 4, activity: "Simple Physics Experiment", subject: "Science" },
    { id: 5, activity: "Write Essay on Environment", subject: "English" },
    { id: 6, activity: "Grammar Worksheet", subject: "English" }
];

// Show Register Section
function showRegister() {
    document.getElementById("loginSection").classList.add("hidden");
    document.getElementById("registerSection").classList.remove("hidden");
}

// Back to Login
function backToLogin() {
    document.getElementById("registerSection").classList.add("hidden");
    document.getElementById("loginSection").classList.remove("hidden");
}

// Register Function
function register() {
    let user = document.getElementById("regUsername").value.trim();
    let pass = document.getElementById("regPassword").value.trim();

    if(user === "" || pass === "") {
        document.getElementById("regMsg").innerText = "All fields required";
        return;
    }

    let exists = students.find(s => s.username === user);
    if(exists) {
        document.getElementById("regMsg").innerText = "Username already exists";
        return;
    }

    students.push({ username: user, password: pass });

    document.getElementById("regMsg").style.color = "green";
    document.getElementById("regMsg").innerText = "Registration Successful!";
}

// Login Function
function login() {
    let user = document.getElementById("username").value.trim();
    let pass = document.getElementById("password").value.trim();

    let validUser = students.find(s => s.username === user && s.password === pass);

    if(validUser) {
        document.getElementById("loginSection").classList.add("hidden");
        document.getElementById("welcomeSection").classList.remove("hidden");
        document.getElementById("errorMsg").innerText = "";
    } else {
        document.getElementById("errorMsg").innerText = "Invalid Username or Password";
    }
}

// Logout
function logout() {
    document.getElementById("welcomeSection").classList.add("hidden");
    document.getElementById("loginSection").classList.remove("hidden");
}

// Open Monthly Page
function openMonthly() {
    document.getElementById("welcomeSection").classList.add("hidden");
    document.getElementById("monthlySection").classList.remove("hidden");
    displayActivities(monthlyActivities);
}

// Back to Welcome
function backToWelcome() {
    document.getElementById("monthlySection").classList.add("hidden");
    document.getElementById("welcomeSection").classList.remove("hidden");
}

// Display Activities
function displayActivities(data) {
    let container = document.getElementById("activityContainer");
    container.innerHTML = "";

    data.forEach(item => {
        let div = document.createElement("div");
        div.className = "activityCard";
        div.innerHTML = `<strong>${item.subject}</strong><br>${item.activity}`;
        container.appendChild(div);
    });
}

// Filter by Subject
function filterActivities() {
    let selected = document.getElementById("subjectSelect").value;

    if(selected === "All") {
        displayActivities(monthlyActivities);
    } else {
        let filtered = monthlyActivities.filter(a => a.subject === selected);
        displayActivities(filtered);
    }
}