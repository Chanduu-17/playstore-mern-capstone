import { useEffect, useRef } from "react";

function useTimer(isRunning, setTime) {

  const intervalRef = useRef(null);

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        setTime(prev => prev + 1);
      }, 1000);
    }

    return () => {
      clearInterval(intervalRef.current);
    };

  }, [isRunning, setTime]);
}

export default useTimer;