import React, { useState } from "react";
import useTimer from "../hooks/useTimer";

function WorkoutTracker() {

  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);

  useTimer(isRunning, setTime);

  return (
    <div className="card p-3 shadow mt-4">
      <h3>Workout Tracker</h3>
      <h4>{time} seconds</h4>

      <button 
        className="btn btn-success m-2"
        onClick={() => setIsRunning(true)}>
        Start
      </button>

      <button 
        className="btn btn-danger m-2"
        onClick={() => setIsRunning(false)}>
        Stop
      </button>
    </div>
  );
}

export default WorkoutTracker;