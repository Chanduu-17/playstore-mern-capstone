import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchProducts, updateProduct } from "../redux/productSlice";

function ProductManager() {

  const dispatch = useDispatch();
  const products = useSelector(state => state.products.items);

  useEffect(() => {
    dispatch(fetchProducts());
  }, [dispatch]);

  const handleUpdate = (product) => {
    dispatch(updateProduct({
      id: product.id,
      title: product.title + " (Updated)"
    }));
  };

  return (
    <div className="mt-4">
      <h3>Product Manager</h3>

      {products.slice(0, 4).map(product => (
        <div key={product.id} className="card p-3 mb-3 shadow">
          <h6>{product.title}</h6>

          <button 
            className="btn btn-warning btn-sm mt-2"
            onClick={() => handleUpdate(product)}
          >
            Update Product
          </button>
        </div>
      ))}
    </div>
  );
}

export default ProductManager;