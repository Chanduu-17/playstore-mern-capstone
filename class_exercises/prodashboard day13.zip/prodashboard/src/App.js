import React, { useContext } from "react";
import { ThemeProvider, ThemeContext } from "./context/ThemeContext";
import WorkoutTracker from "./components/WorkoutTracker";
import ProductManager from "./components/ProductManager";
import OfflineBanner from "./components/OfflineBanner";
import { Provider } from "react-redux";
import { store } from "./redux/store";
import "bootstrap/dist/css/bootstrap.min.css";

function MainApp() {
  const { theme, toggleTheme } = useContext(ThemeContext);

  return (
    <div className={theme === "dark" ? "bg-dark text-white min-vh-100 p-3" : "bg-light min-vh-100 p-3"}>
      <OfflineBanner />
      <h1 className="text-center">Professional Dashboard</h1>

      <button className="btn btn-primary" onClick={toggleTheme}>
        Toggle Theme
      </button>

      <WorkoutTracker />
      <ProductManager />
    </div>
  );
}

function App() {
  return (
    <Provider store={store}>
      <ThemeProvider>
        <MainApp />
      </ThemeProvider>
    </Provider>
  );
}

export default App;