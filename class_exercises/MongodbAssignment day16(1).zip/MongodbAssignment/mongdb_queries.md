 User Story 1 – Database Setup

use BookVerseDB

db.authors.insertMany([...])
db.books.insertMany([...])
db.users.insertMany([...])



 User Story 2 – CRUD Operations

db.users.insertOne({...})                    -- Create user
db.books.insertOne({...})                    -- Create book

db.books.find({genre: "Science Fiction"})    -- Read

db.books.updateOne({...})                    -- Update publicationYear

db.users.deleteOne({...})                    -- Delete user

db.books.updateOne({$push: {ratings: {...}}}) -- Add rating



 User Story 3 – Filtering Queries

db.books.find({publicationYear: {$gt: 2015}})

db.authors.aggregate([...])                  -- Authors with Fantasy books

db.users.find({joinDate: {$gte: ...}})       -- Users joined in last 6 months

db.books.aggregate([...])                    -- Books with avg rating > 4



 Bonus Query

db.books.aggregate([...])                    -- Top 3 most rated books