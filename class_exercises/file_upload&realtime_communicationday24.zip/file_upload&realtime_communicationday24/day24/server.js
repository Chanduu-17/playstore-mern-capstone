const express = require("express");
const multer = require("multer");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = 4000;


/* ======================================
   Challenge 1 — File Upload using Multer
====================================== */

const storage = multer.diskStorage({

    destination: (req, file, cb) => {
        cb(null, "uploads");
    },

    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }

});

const upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {

        if (file.mimetype === "application/pdf") {
            cb(null, true);
        } else {
            cb(new Error("Only PDF files allowed"));
        }

    }
});

app.post("/upload", upload.single("material"), (req, res) => {

    res.send(`File uploaded successfully: ${req.file.originalname}`);

});


/* ======================================
   Challenge 2 — Serve Static Files
====================================== */

app.use("/materials", express.static(path.join(__dirname, "uploads")));


/* ======================================
   Serve Chat Page
====================================== */

app.use(express.static("public"));


/* ======================================
   Challenge 3 — Real-Time Chat
====================================== */

io.on("connection", (socket) => {

    console.log("User connected");

    socket.on("chatMessage", (msg) => {

        io.emit("chatMessage", msg);

    });

    socket.on("disconnect", () => {

        console.log("User disconnected");

    });

});


/* ======================================
   Start Server
====================================== */

server.listen(PORT, () => {

    console.log(`Server running at http://localhost:${PORT}`);

});