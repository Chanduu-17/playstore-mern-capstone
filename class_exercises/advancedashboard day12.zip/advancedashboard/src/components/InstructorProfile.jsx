import React from "react";

function InstructorProfile() {
  console.log("InstructorProfile Rendered");

  return (
    <div className="card mt-4 shadow bg-light">
      <div className="card-body">
        <h3 className="text-warning">Abhishek Sharma</h3>
        <p>Senior React Developer with 10 years experience.</p>
      </div>
    </div>
  );
}

export default InstructorProfile;