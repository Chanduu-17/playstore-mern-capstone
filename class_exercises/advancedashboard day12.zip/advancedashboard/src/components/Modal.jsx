import React from "react";
import ReactDOM from "react-dom";
import "./modal.css";

function Modal({ closeModal }) {
  return ReactDOM.createPortal(
    <div className="modal-overlay">
      <div className="modal-card">

        <h3 className="modal-title">
          Notification
        </h3>

        <p className="modal-text">
          Your course has been successfully updated!
        </p>

        <button className="btn btn-primary mt-3" onClick={closeModal}>
          Close
        </button>

      </div>
    </div>,
    document.getElementById("portal-root")
  );
}

export default Modal;