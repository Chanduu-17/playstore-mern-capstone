import React from "react";
import course from "../assets/course.jpg";

function CourseDetails() {
  console.log("CourseDetails Rendered");

  return (
    <div className="card mt-4 shadow">
      <img src={course} className="card-img-top" alt="course" />
      <div className="card-body">
        <h3 className="card-title text-success">React Mastery Course</h3>
        <p>Learn React from beginner to advanced concepts.</p>
      </div>
    </div>
  );
}

export default CourseDetails;