import React, { memo } from "react";

function StatsCard({ title, value, lastUpdated }) {
  console.log(title + " Re-rendered");

  return (
    <div className="col-md-6 mb-3">
      <div className="card text-center shadow-lg border-0 bg-info text-white">
        <div className="card-body">
          <h5>{title}</h5>
          <h2>{value}</h2>
          <small>Last Updated: {lastUpdated}</small>
        </div>
      </div>
    </div>
  );
}

export default memo(StatsCard);