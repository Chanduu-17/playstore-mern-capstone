import React, { useState, Suspense, lazy } from "react";
import "./App.css";
import StatsCard from "./components/StatsCard";
import ErrorBoundary from "./components/ErrorBoundary";
import Modal from "./components/Modal";

const CourseDetails = lazy(() => import("./components/CourseDetails"));
const InstructorProfile = lazy(() => import("./components/InstructorProfile"));

function App() {

  const [showCourse, setShowCourse] = useState(false);
  const [showInstructor, setShowInstructor] = useState(false);
  const [openModal, setOpenModal] = useState(false);

  const [students, setStudents] = useState(1200);
  const [courses, setCourses] = useState(45);

  const simulateUpdate = () => {
    setStudents(prev => prev + 1);
  };

  return (
    <div className="container mt-4">

      <h1 className="text-center text-primary mb-4">
        🎓 Online Learning Dashboard
      </h1>

      <div className="row">
        <StatsCard title="Students" value={students} lastUpdated="Just Now" />
        <StatsCard title="Courses" value={courses} lastUpdated="Today" />
      </div>

      <div className="text-center mt-3">
        <button className="btn btn-dark" onClick={simulateUpdate}>
          Simulate Update
        </button>
      </div>

      <div className="text-center mt-4">
        <button className="btn btn-success m-2"
          onClick={() => setShowCourse(true)}>
          View Course Details
        </button>

        <button className="btn btn-warning m-2"
          onClick={() => setShowInstructor(true)}>
          View Instructor Profile
        </button>

        <button className="btn btn-danger m-2"
          onClick={() => setOpenModal(true)}>
          Open Notification
        </button>
      </div>

      <Suspense fallback={
        <div className="text-center mt-4">
          <div className="spinner-border text-info"></div>
          <p>Loading Module...</p>
        </div>
      }>
        {showCourse && <CourseDetails />}
        {showInstructor && <InstructorProfile />}
      </Suspense>

      <ErrorBoundary>
        {openModal && <Modal closeModal={() => setOpenModal(false)} />}
      </ErrorBoundary>

    </div>
  );
}

export default App;