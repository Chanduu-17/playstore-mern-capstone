const express = require("express");

const app = express();
const PORT = 4000;

// Needed for POST requests later
app.use(express.json());



app.use((req, res, next) => {

    const time = new Date().toISOString();

    console.log(`[${req.method}] ${req.url} - ${time}`);

    next();

});




// root route
app.get("/", (req, res) => {

    res.send("Welcome to Express Server");

});

// bonus status route
app.get("/status", (req, res) => {

    res.json({
        server: "running",
        uptime: "OK"
    });

});




app.get("/products", (req, res) => {

    const productName = req.query.name;

    if (productName) {

        res.json({
            query: productName
        });

    } else {

        res.send("Please provide a product name");

    }

});




const bookRouter = require("./routes/books");

app.use("/books", bookRouter);




// 404 handler
app.use((req, res) => {

    res.status(404).json({
        message: "Route not found"
    });

});

// internal error handler
app.use((err, req, res, next) => {

    console.error(err.stack);

    res.status(500).json({
        error: "Internal Server Error"
    });

});




app.listen(PORT, () => {

    console.log(`Server running at http://localhost:${PORT}`);

});