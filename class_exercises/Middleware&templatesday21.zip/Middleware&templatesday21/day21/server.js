const express = require("express");

const app = express();
const PORT = 4000;




app.use((req, res, next) => {

    const timestamp = new Date().toISOString();

    console.log(`[${req.method}] ${req.url} at ${timestamp}`);

    next();

});



app.use(express.json());
app.use(express.urlencoded({ extended: true }));




app.post("/users", (req, res) => {

    const userData = req.body;

    res.json({
        message: "User created successfully",
        data: userData
    });

});




// set EJS as view engine
app.set("view engine", "ejs");


// sample course data
const courses = [
    { id: 1, title: "React Mastery", duration: "6 weeks" },
    { id: 2, title: "Node.js Essentials", duration: "4 weeks" },
    { id: 3, title: "Full Stack Bootcamp", duration: "8 weeks" }
];


// route to render courses page
app.get("/courses", (req, res) => {

    res.render("courses", { courses });

});




app.get("/", (req, res) => {

    res.send("SkillSphere LMS API is running");

});




app.listen(PORT, () => {

    console.log(`Server running at http://localhost:${PORT}`);

});