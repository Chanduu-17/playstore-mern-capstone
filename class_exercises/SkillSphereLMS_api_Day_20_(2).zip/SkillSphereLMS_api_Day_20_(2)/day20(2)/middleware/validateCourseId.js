function validateCourseId(req, res, next) {

    const courseId = req.params.id;

    // Check if numeric
    if (!/^\d+$/.test(courseId)) {

        return res.status(400).json({
            error: "Invalid course ID"
        });

    }

    next();
}

module.exports = validateCourseId;