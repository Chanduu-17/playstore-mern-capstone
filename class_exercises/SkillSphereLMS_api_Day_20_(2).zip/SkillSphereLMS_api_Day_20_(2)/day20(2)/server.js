const express = require("express");

const app = express();
const PORT = 4000;

// Import course routes
const courseRoutes = require("./routes/courses");

// Root route (Challenge 1)
app.get("/", (req, res) => {
    res.send("Welcome to SkillSphere LMS API");
});

// Mount course routes
app.use("/courses", courseRoutes);

// Start server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});