const fs = require("fs").promises;
const readline = require("readline");

// create CLI input interface
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

async function handleFeedback() {

    rl.question("Enter your feedback: ", async (message) => {

        try {

            // write data to file
            await fs.writeFile("feedback.txt", message);

            console.log("Data written successfully.");

            console.log("Reading file...");

            // read the file
            const data = await fs.readFile("feedback.txt", "utf8");

            console.log(data);

        } catch (error) {

            console.log("Error:", error);

        }

        rl.close();
    });
}

handleFeedback();