const EventEmitter = require("events");
const emitter = new EventEmitter();
const userName = "Chandu";
// register login event
emitter.on("userLoggedIn", (name) => {

    console.log(`User ${name} logged in.`);

});
// register logout event
emitter.on("userLoggedOut", (name) => {

    console.log(`User ${name} logged out.`);

});

// session expired event
emitter.on("sessionExpired", (name) => {

    console.log(`Session expired for ${name}.`);

});

// emit login
emitter.emit("userLoggedIn", userName);

// emit logout
emitter.emit("userLoggedOut", userName);

// emit session expired after 5 seconds
setTimeout(() => {

    emitter.emit("sessionExpired", userName);

}, 5000);