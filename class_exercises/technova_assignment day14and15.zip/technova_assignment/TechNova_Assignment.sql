#USERSTORY1

DROP DATABASE IF EXISTS TechNovaDB;
CREATE DATABASE TechNovaDB;
USE TechNovaDB;

CREATE TABLE Department (
    DeptID INT PRIMARY KEY,
    DeptName VARCHAR(50) NOT NULL UNIQUE,
    Location VARCHAR(50)
);
CREATE TABLE Employee (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(100) NOT NULL,
    Gender CHAR(1),
    DOB DATE,
    HireDate DATE,
    DeptID INT,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);
CREATE TABLE Project (
    ProjectID INT PRIMARY KEY,
    ProjectName VARCHAR(100),
    DeptID INT,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);
CREATE TABLE Performance (
    EmpID INT,
    ProjectID INT,
    Rating DECIMAL(3,1),
    ReviewDate DATE,
    PRIMARY KEY (EmpID, ProjectID),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID),
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID)
);
CREATE TABLE Reward (
    EmpID INT,
    RewardMonth DATE,
    RewardAmount DECIMAL(10,2),
    PRIMARY KEY (EmpID, RewardMonth),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);
CREATE INDEX idx_empname ON Employee(EmpName);
CREATE INDEX idx_deptid ON Employee(DeptID);


#USERSTORY2
INSERT INTO Department VALUES
(101,'IT','Bangalore'),
(102,'HR','Delhi'),
(103,'Finance','Mumbai'),
(104,'Marketing','Hyderabad'),
(105,'Operations','Chennai');
INSERT INTO Employee VALUES
(1,'Asha','F','1990-07-12','2018-06-10',101),
(2,'Raj','M','1988-04-09','2020-03-22',102),
(3,'Neha','F','1995-01-15','2021-08-05',101),
(4,'Kiran','M','1992-11-30','2019-02-18',103),
(5,'Priya','F','1993-05-20','2022-04-10',104);
INSERT INTO Project VALUES
(201,'Inventory System',101,'2023-01-01','2023-12-31'),
(202,'HR Portal',102,'2023-02-01','2023-10-01'),
(203,'Finance Tracker',103,'2023-03-15','2023-11-30'),
(204,'Marketing Analytics',104,'2023-04-01','2023-12-15'),
(205,'Operations Automation',105,'2023-05-01','2023-12-31');
INSERT INTO Performance VALUES
(1,201,4.5,'2023-06-30'),
(2,202,4.2,'2023-07-15'),
(3,201,4.8,'2023-08-01'),
(4,203,4.0,'2023-07-20'),
(5,204,4.6,'2023-08-10');
INSERT INTO Reward VALUES
(1,'2024-01-01',600),
(2,'2024-01-01',900),
(3,'2024-02-01',3000),
(4,'2024-02-01',1500),
(5,'2024-03-01',2200);
UPDATE Employee
SET DeptID = 103
WHERE EmpID = 2;
DELETE FROM Reward
WHERE RewardAmount < 1000;

#USERSTORY3

SELECT *
FROM Employee
WHERE HireDate > '2019-01-01';
SELECT d.DeptName, AVG(p.Rating) AS AvgRating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
GROUP BY d.DeptName;
SELECT EmpName,
TIMESTAMPDIFF(YEAR, DOB, CURDATE()) AS Age
FROM Employee;
SELECT SUM(RewardAmount) AS TotalRewards
FROM Reward
WHERE YEAR(RewardMonth) = YEAR(CURDATE());
SELECT e.EmpName, r.RewardAmount
FROM Employee e
JOIN Reward r ON e.EmpID = r.EmpID
WHERE r.RewardAmount > 2000;

#USERSTORY4

SELECT e.EmpName,
d.DeptName,
p.ProjectName,
pf.Rating
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Performance pf ON e.EmpID = pf.EmpID
JOIN Project p ON pf.ProjectID = p.ProjectID;
SELECT EmpName, DeptName, Rating
FROM (
    SELECT e.EmpName, d.DeptName, p.Rating,
           RANK() OVER (PARTITION BY d.DeptName ORDER BY p.Rating DESC) AS rnk
    FROM Employee e
    JOIN Department d ON e.DeptID = d.DeptID
    JOIN Performance p ON e.EmpID = p.EmpID
) t
WHERE rnk = 1;
SELECT EmpName
FROM Employee
WHERE EmpID NOT IN (
    SELECT EmpID FROM Reward
);

#USERSTORY5

START TRANSACTION;

INSERT INTO Employee
VALUES (6,'Arjun','M','1996-09-14','2024-01-10',101);

INSERT INTO Performance
VALUES (6,201,4.3,'2024-03-01');

COMMIT;
EXPLAIN
SELECT e.EmpName, d.DeptName, p.ProjectName
FROM Employee e
JOIN Department d ON e.DeptID=d.DeptID
JOIN Project p ON d.DeptID=p.DeptID;
EXPLAIN
SELECT e.EmpName, d.DeptName, p.ProjectName
FROM Employee e
JOIN Department d ON e.DeptID=d.DeptID
JOIN Project p ON d.DeptID=p.DeptID;

#BONUS

CREATE VIEW EmployeePerformanceView AS
SELECT e.EmpName,
d.DeptName,
p.ProjectName,
pf.Rating
FROM Employee e
JOIN Department d ON e.DeptID=d.DeptID
JOIN Performance pf ON e.EmpID=pf.EmpID
JOIN Project p ON pf.ProjectID=p.ProjectID;
SELECT * FROM EmployeePerformanceView;
DELIMITER $$

CREATE PROCEDURE GetTopPerformers(IN deptName VARCHAR(50))
BEGIN
SELECT e.EmpName, p.Rating
FROM Employee e
JOIN Department d ON e.DeptID=d.DeptID
JOIN Performance p ON e.EmpID=p.EmpID
WHERE d.DeptName = deptName
ORDER BY p.Rating DESC
LIMIT 3;
END $$

DELIMITER ;
CALL GetTopPerformers('IT');
show tables;
SELECT * FROM Department;
SELECT * FROM Employee;
SELECT * FROM Project;
SELECT * FROM Reward;

SELECT d.DeptName, AVG(p.Rating)
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
GROUP BY d.DeptName;

SELECT EmpName,
TIMESTAMPDIFF(YEAR, DOB, CURDATE()) AS Age
FROM Employee;

SELECT e.EmpName, d.DeptName, p.ProjectName, pf.Rating
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Performance pf ON e.EmpID = pf.EmpID
JOIN Project p ON pf.ProjectID = p.ProjectID;

SELECT * FROM EmployeePerformanceView;