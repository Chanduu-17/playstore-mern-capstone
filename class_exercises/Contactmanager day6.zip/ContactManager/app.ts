interface Contact {
    id: number;
    name: string;
    email: string;
    phone: string;
}

class ContactManager {
    private contacts: Contact[] = [];

    addContact(contact: Contact): string {
        if (this.contacts.find(c => c.id === contact.id)) {
            return "error: Contact ID already exists!";
        }
        this.contacts.push(contact);
        return "success: Contact added successfully!";
    }

    viewContacts(): Contact[] {
        return this.contacts;
    }

    modifyContact(id: number, updated: Partial<Contact>): string {
        const contact = this.contacts.find(c => c.id === id);
        if (!contact) {
            return "error: Contact not found!";
        }
        Object.assign(contact, updated);
        return "success: Contact updated successfully!";
    }

    deleteContact(id: number): string {
        const index = this.contacts.findIndex(c => c.id === id);
        if (index === -1) {
            return "error: Contact not found!";
        }
        this.contacts.splice(index, 1);
        return "success: Contact deleted successfully!";
    }
}

const manager = new ContactManager();

/* 🔔 Notification Function */
function showNotification(message: string) {
    const notification = document.getElementById("notification")!;
    
    notification.className = "notification";
    
    if (message.startsWith("success")) {
        notification.classList.add("success");
    } else {
        notification.classList.add("error");
    }

    notification.textContent = message.split(": ")[1];
    notification.classList.add("show");

    setTimeout(() => {
        notification.classList.remove("show");
    }, 3000);
}

function displayContacts() {
    const table = document.getElementById("contactTable")!;
    table.innerHTML = "";

    manager.viewContacts().forEach(contact => {
        table.innerHTML += `
        <tr>
            <td>${contact.id}</td>
            <td>${contact.name}</td>
            <td>${contact.email}</td>
            <td>${contact.phone}</td>
        </tr>`;
    });
}

function addContact() {
    const id = Number((document.getElementById("id") as HTMLInputElement).value);
    const name = (document.getElementById("name") as HTMLInputElement).value;
    const email = (document.getElementById("email") as HTMLInputElement).value;
    const phone = (document.getElementById("phone") as HTMLInputElement).value;

    const msg = manager.addContact({ id, name, email, phone });
    showNotification(msg);
    displayContacts();
}

function updateContact() {
    const id = Number((document.getElementById("id") as HTMLInputElement).value);
    const name = (document.getElementById("name") as HTMLInputElement).value;
    const email = (document.getElementById("email") as HTMLInputElement).value;
    const phone = (document.getElementById("phone") as HTMLInputElement).value;

    const msg = manager.modifyContact(id, { name, email, phone });
    showNotification(msg);
    displayContacts();
}

function deleteContact() {
    const id = Number((document.getElementById("id") as HTMLInputElement).value);
    const msg = manager.deleteContact(id);
    showNotification(msg);
    displayContacts();
}

/* Make functions global */
(window as any).addContact = addContact;
(window as any).updateContact = updateContact;
(window as any).deleteContact = deleteContact;