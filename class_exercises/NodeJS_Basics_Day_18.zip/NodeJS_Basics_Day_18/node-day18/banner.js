const figlet = require("figlet");
const chalk = require("chalk");

figlet("Welcome to Node.js", function (err, data) {

    if (err) {
        console.log("Error generating banner:", err);
        return;
    }

    console.log(chalk.blue(data));
    console.log(chalk.green("Your Node.js environment is ready!"));
});