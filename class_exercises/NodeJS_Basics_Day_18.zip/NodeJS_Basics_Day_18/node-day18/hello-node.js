console.log("Node Version:", process.version);
console.log("Current File:", __filename);
console.log("Current Directory:", __dirname);

console.log("Node.js script started...");
const timer = setInterval(() => {
    console.log("Welcome to Node.js backend development!");
}, 3000);

setTimeout(() => {
    clearInterval(timer);
    console.log("Timer stopped after 10 seconds.");
}, 10000);