const moment = require("moment");

// Get name from command line
const args = process.argv;
const userName = args[2];

// Validate input
if (!userName) {
    console.log("Please provide your name.");
    console.log("Example: node greet.js Chandu");
    process.exit();
}

// Get formatted date
const currentDate = moment().format("ddd MMM Do YYYY, h:mm A");

// Display greeting
console.log(`Hello, ${userName}! Today is ${currentDate}`);