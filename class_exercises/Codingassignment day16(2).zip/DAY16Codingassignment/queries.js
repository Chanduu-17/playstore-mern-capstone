#INDEX CREATION COMMANDS
// Index on genre
db.books.createIndex({ genre: 1 })

// Index on authorId
db.books.createIndex({ authorId: 1 })

// Index on ratings score
db.books.createIndex({ "ratings.score": 1 })

// View all indexes
db.books.getIndexes()

// Drop unnecessary index example
db.books.dropIndex({ authorId: 1 })

#AGGREGATION QUERIES
1.AVG RATING PER BOOK

db.books.aggregate([
  { $unwind: "$ratings" },
  {
    $group: {
      _id: "$title",
      averageRating: { $avg: "$ratings.score" }
    }
  }
])

2.TOP 3 HIGHEST RATED BOOKS
db.books.aggregate([
  { $unwind: "$ratings" },
  {
    $group: {
      _id: "$title",
      avgRating: { $avg: "$ratings.score" }
    }
  },
  { $sort: { avgRating: -1 } },
  { $limit: 3 }
])

3.COUNT BOOKS PUBLISHED PER GENRE
db.books.aggregate([
  {
    $group: {
      _id: "$genre",
      totalBooks: { $sum: 1 }
    }
  }
])

4.AUTHORS WITH MORE THAN 2 BOOKS
db.books.aggregate([
  {
    $group: {
      _id: "$authorId",
      bookCount: { $sum: 1 }
    }
  },
  {
    $match: { bookCount: { $gt: 2 } }
  }
])

5.TOTAL RATING POINTS PER AUTHORS
db.books.aggregate([
  { $unwind: "$ratings" },
  {
    $group: {
      _id: "$authorId",
      totalRatingPoints: { $sum: "$ratings.score" }
    }
  }
])