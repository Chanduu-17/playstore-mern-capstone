import React, { useState } from "react";
import BookCard from "./BookCard";

function BookList() {

  const booksData = [
    { id: 1, title: "The Alchemist", author: "Paulo Coelho", price: 399 },
    { id: 2, title: "Atomic Habits", author: "James Clear", price: 499 },
    { id: 3, title: "Rich Dad Poor Dad", author: "Robert Kiyosaki", price: 350 },
    { id: 4, title: "Ikigai", author: "Hector Garcia", price: 450 },
    { id: 5, title: "Deep Work", author: "Cal Newport", price: 420 }
  ];

  const [viewMode, setViewMode] = useState("grid");
  const [searchTerm, setSearchTerm] = useState("");

  const filteredBooks = booksData.filter((book) =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>

      <div className="controls">
        <button onClick={() => setViewMode("grid")}>Grid View</button>
        <button onClick={() => setViewMode("list")}>List View</button>
      </div>

      <input
        type="text"
        placeholder="Search books..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="search-box"
      />

      <div className={viewMode === "grid" ? "grid-container" : "list-container"}>
        {filteredBooks.map((book) => (
          <BookCard
            key={book.id}
            title={book.title}
            author={book.author}
            price={book.price}
            viewMode={viewMode}
          />
        ))}
      </div>
    </div>
  );
}

export default BookList;